var canvas = document.querySelector('canvas');

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

var c = canvas.getContext('2d');

window.addEventListener('resize', function(event){
	canvas.width = window.innerWidth;
	canvas.height = window.innerHeight;
});

var mouse = {
	x: innerWidth/2,
	y: undefined
}

window.addEventListener('mousemove', function(event){
	mouse.x = event.x;
	mouse.y = event.y;
});

var colorArray = [
				'#5AFF15',
				'#E4572E',
				'#B14AED',
				'#F4FF52',
				'#1E2EDE',
				'#EF476F',
				'#FA8334',
		];
			
function Particle(x, y, dx, dy, exp, dis, id) {
	this.explosion = 0;
	this.x = x;
	this.y = y;
	this.dx = dx;
	this.dy = dy;
	this.radius = 2;
	this.exploded = exp;
	this.dis = dis;
	this.id = id;
	this.color = colorArray[Math.floor(Math.random() * colorArray.length)];
	this.boomStyle = Math.floor(Math.random() * 3);
	
	this.draw = function() {
		c.beginPath();
		c.strokeStyle = this.color;
		c.arc(this.x, this.y, this.radius, 0, Math.PI * 2, false);
		c.lineWidth = 6;
		c.stroke();
		c.fillStyle = this.color;
		c.fill();
		c.closePath();
	}
	
	this.update = function(){
	if (this.dy > -this.dis)
	{
	this.x += this.dx;
	this.y -= this.dy;
	this.dy = this.dy - 0.4;
	this.draw();
	}
	else{
		if(this.exploded==0){
			switch(this.boomStyle){
				case 0: {explode1(this.x, this.y, this.dx); break;}
				case 1: {explode2(this.x, this.y, this.dx); break;}
				case 2: {explode3(this.x, this.y, this.dx); break;}
				default: {explode1(this.x, this.y, this.dx); break;}
			}
			
			this.exploded = 1;
		}
	}
	if(this.y > innerHeight){
		
		particleArray.splice(this.id, 1);}
	}
	}
	
function explode1(x, y, dx){
	for(var i=0; i<40; i++){
	particleArray.push(new Particle(x, y, getSpeed(8)+dx/2, getSpeed(8)+5, 1, Math.random()*5+10)); id++;}
}

function explode2(x, y, dx){
	for(var i=0; i<40; i++){
	particleArray.push(new Particle(x, y, getSpeed(8)+dx/2, getSpeed(8)+5, 1, Math.random()*5+10)); id++;}
}

function explode3(x, y, dx){
	for(var i=0; i<4; i++){
	particleArray.push(new Particle(x, y, getSpeed(8)+dx/2, getSpeed(8)+5, 0, Math.random()*5+10)); id++;}
}
	
function getSpeed(v){return (Math.random() - 0.5)*v;}
	
var particleArray = [];

window.addEventListener("click", makeNew);

var id = 0;

function makeNew(){
particleArray.push(new Particle(innerWidth/2, innerHeight, getSpeed(15), Math.random()*5+20, 0, 10, id)); id++;}
var iter = 0;

function animate(){
	requestAnimationFrame(animate);
	if(iter == 2){
	c.fillStyle = 'rgb(53, 54, 58, 0.5)';
	c.fillRect(0, 0, innerWidth, innerHeight);
	iter = 0;
	}
	else iter++;
	
	for(var i=0; i<particleArray.length; i++)
	{
	particleArray[i].update();
	}
}
