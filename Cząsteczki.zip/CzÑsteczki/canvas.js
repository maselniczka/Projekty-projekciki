var canvas = document.querySelector('canvas');
var lines = false;

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

var c = canvas.getContext('2d');

window.addEventListener('resize', function(event){
	canvas.width = window.innerWidth;
	canvas.height = window.innerHeight;
});

var color_scheme = 0;
var color_switch = 0;

document.addEventListener('click', function(){color_scheme++; color_switch = am;});

var mouse = {
	x: undefined,
	y: undefined
}

window.addEventListener('mousemove', function(event){
	mouse.x = event.x;
	mouse.y = event.y;
});

function Circle(i) {
	this.radius = Math.random() * 100;
	this.x = Math.random() * (innerWidth - this.radius*2) + this.radius;
	this.y = Math.random() * (innerHeight - this.radius*2) + this.radius;
	this.dx = (Math.random() - 0.5) * 5;
	this.dy = (Math.random() - 0.5) * 5;
	this.i = i;
	this.getColor = function(){
	switch(color_scheme){
		case 0:
			document.body.style.backgroundColor = '#0C0F0A';
			if(this.i > am-(2/100*am)){
				this.color = '#FF206E';
				}
			else {
				if(this.i > am-(1/10*am)) this.color = '#FBFF12';
				else{if(this.i > am-(25/100*am)) this.color = '#41EAD4';
					else this.color = '#FFFFFF';
				}
			} 
			break;
		case 1:
			document.body.style.backgroundColor = '#FFCBDD';
			if(this.i > am-(2/100*am)){
				this.color = '#3E000C';
				}
			else {
				if(this.i > am-(1/10*am)) this.color = '#7C0B2B';
				else{if(this.i > am-(33/100*am)) this.color = '#D10000';
					else this.color = '#FB4B4E';
				}
				
		} 	break;
		case 2:
			document.body.style.backgroundColor = '#222222';
			if(this.i > am-(0.25/100*am)){
				this.color = '#EE0000';
				}
			else {
					this.color = '#000000';
				}
				
		 	break;
		case 3:
			document.body.style.backgroundColor = '#FFBC0A';
			if(this.i > am-(2/100*am)){
				this.color = '#C200FB';
				}
			else {
				if(this.i > am-(1/10*am)) this.color = '#EC0868';
				else{if(this.i > am-(25/100*am)) this.color = '#FC2F00';
					else this.color = '#EC7D10';
				}
				
		} 	break;
		case 4:
			document.body.style.backgroundColor = '#475B63';
			if(this.i > am-(2/100*am)){
				this.color = '#2E2C2F';
				}
			else {
				if(this.i > am-(1/10*am)) this.color = '#F3E8EE';
				else{if(this.i > am-(25/100*am)) this.color = '#729B79';
					else this.color = '#BACDB0';
				}
				
		} 	break;
		case 5:
			document.body.style.backgroundColor = 'black';
			var colorArray = [
				'#BAF2BB',
				'#BAF2D8',
				'#BAD7F2',
				'#F2BAC9',
				'#F2E2BA',
				'#C3ACCE',
				'#3C4F76',
			];
			this.color = colorArray[Math.floor(Math.random() * colorArray.length)];
				
		break;
		case 6:
			document.body.style.backgroundColor = '#EEFCCE';
			if(this.i > am-(2/100*am)){
				this.color = '#9EB25D';
				}
			else {
				if(this.i > am-(1/10*am)) this.color = '#F1DB4B';
				else{if(this.i > am-(25/100*am)) this.color = '#EDFF71';
					else this.color = '#A7C6DA';
				}
				
		} 	break;
		case 7:
			document.body.style.backgroundColor = '#DAE0F2';
			if(this.i > am-(2/100*am)){
				this.color = '#111344';
				}
			else {
				if(this.i > am-(1/10*am)) this.color = '#111344';
				else{if(this.i > am-(33/100*am)) this.color = '#F9CFF2';
					else this.color = '#AA00AA';
				}
				
		} 	break;
		case 8:
			document.body.style.backgroundColor = '#F3F9D2';
			if(this.i > am-(6/100*am)){
				this.color = '#9CAFB7';
				}
			else {
				if(this.i > am-(12.5/100*am)) this.color = '#EFC69B';
				else{if(this.i > am-(50/100*am)) this.color = '#C0D684';
					else this.color = '#CBEAA6';
				}
				
		} 	break;
		case 9:
			document.body.style.backgroundColor = '#F3D9B1';
			if(this.i > am-(2/100*am)){
				this.color = '#400406';
				}
			else {
				if(this.i > am-(1/10*am)) this.color = '#9F7E69';
				else{if(this.i > am-(20/100*am)) this.color = '#4E3822';
					else this.color = '#AD8350';
				}
				
		} 	break;
		
		default: color_scheme = 0;
	}};
		
	this.getColor();
	
	this.draw = function() {
		c.beginPath();
		c.strokeStyle = this.color;
		c.arc(this.x, this.y, this.radius, 0, Math.PI * 2, false);
		c.lineWidth = 0;
		c.stroke();
		c.fillStyle = this.color;
		c.fill();
		c.closePath();
	}

	
	this.update = function() {
		if (this.x + this.radius > innerWidth || this.x - this.radius < 0) {
		this.dx = -this.dx;
	}
		if (this.y + this.radius > innerHeight|| this.y - this.radius < 0) {
		this.dy = -this.dy;
	}	
		if(this.x > innerWidth + 20){this.x = Math.random() * (innerWidth - this.radius*2) + this.radius;}
		if(this.y > innerHeight + 20){this.y = Math.random() * (innerHeight - this.radius*2) + this.radius;}
		
		this.x += this.dx;
		this.y += this.dy;
			if(mouse.x - this.x < 5/100*innerHeight && mouse.x - this.x > -5/100*innerHeight && mouse.y - this.y < 5/100*innerHeight && mouse.y - this.y > -5/100*innerHeight){
				if(this.radius < innerWidth/20) this.radius += 3;		
			}
			else {
				if(this.radius > 1) this.radius--;
			}
			if(color_switch >= 0){
			this.getColor();
			color_switch--;}
			this.draw();
	}
}

var am=0;
var circleArray = [];
function start(){
	am = prompt('jak dużo kulek (1000 jest fajnie)\nim więcej i w mniejszym oknie tym fajniej uwu \n(ale jak za dużo to laguje trochę)');
	
	for(var i=0; i<am; i++){
	circleArray.push(new Circle(i));
	}
	animate();
}

function animate(){
	requestAnimationFrame(animate);
	c.clearRect(0, 0, innerWidth, innerHeight);
	for(var i=0; i<circleArray.length; i++)
	{
	circleArray[i].update();
	}
}