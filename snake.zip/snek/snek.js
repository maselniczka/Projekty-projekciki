function setup() {
  createCanvas(500, 500);
  frameRate(20);
  strokeWeight(0);
  chgcolors();
}

function draw() {
  background(colorArray[c][1]);
  if(game == 0) udied();
  drawScore();
  fond.draw();
  snek.update();
  }


function keyPressed() {
if(game == 1){
  if (keyCode === UP_ARROW) {
    snek.dy = -1; snek.dx = 0;
  } else if (keyCode === DOWN_ARROW) {
    snek.dy = 1; snek.dx = 0;
  }
  if (keyCode === LEFT_ARROW) {
    snek.dx = -1; snek.dy = 0;
  } else if (keyCode === RIGHT_ARROW) {
    snek.dx = 1; snek.dy = 0;
  }
  if(keyCode == ENTER) {snek.dx = 0; snek.dy=0;}
}
}

function food(){
    this.x = undefined;
    this.y = undefined;

    this.spawn = function(){
        this.x = Math.floor(Math.random()*49);
        this.y = Math.floor(Math.random()*49);
        for(var i=0; i < snek.been.length; i++){
            if(this.x == snek.been[i][0] && this.y == snek.been[i][1]) this.spawn();
        }

     this.draw = function(){
        fill(colorArray[c][2]);
        rect(this.x*10, this.y*10, 10, 10);
     }
    }
}

function snake(){
    this.x = 25;
    this.y = 0;
    this.dx = 0;
    this.dy = 0;
    this.been = [];
    this.shiftbit = 0;

    this.draw = function(){
        fill(colorArray[c][3]);
        rect(this.x*10, this.y*10, 10, 10);
        for(var i=0; i < this.been.length; i++){
            rect(this.been[i][0]*10, this.been[i][1]*10, 10, 10);
        }
    }

    this.update = function(){
      this.x += this.dx;
      this.y += this.dy;
      for(var i=0; i < this.been.length; i++){
            if(this.x == this.been[i][0] && this.y == this.been[i][1]) gameOver();
       }

       if(this.x > 49 || this.x < 0 || this.y < 0 || this.y > 49) gameOver();
       this.draw();
       this.been.push([this.x, this.y])
       if(this.shiftbit == 1)this.shiftbit--;
       else this.been.shift();
       if(this.x == fond.x && this.y == fond.y) this.consume();
       }

    this.consume = function(){
        this.shiftbit++;
        fond.spawn();
        chgcolors();
        score++;
    }
}

function gameOver(){
    snek.dx = 0; snek.dy = 0;
    game = 0;
}

function udied(){
    if(blink < 25){
         textSize(32);
         fill(colorArray[c][4]);
         blink++;
         text('game over \npress f5 to play again', 10, 30);
    }
    else{
        blink++;
        fill(colorArray[c][1]);
        rect(0, 0, 400, 100);
    }
    if(blink == 40) blink = 0;

}

function chgcolors(){
    c = randomColor(c);
    document.body.style.backgroundColor = colorArray[c][0];
}
function randomColor(c){                //hey look i can do proper functions!
    nc = Math.floor(Math.random()*colorArray.length);
    if(nc == c) return randomColor(c);
    else return nc;
}
function drawScore(){
    textSize(20);
    fill(colorArray[c][4]);
    text('score:', 420, 420);
    textSize(40);
    text(score, 435, 460);
}

var colorArray = [
["#404E7C", //background
"#251F47cc",  //playground
"#71B48D",  //food
"#86CB92",  //snake
"#86CB92"   //text
],
["#313638", //background
"#E0DFD5cc",  //playground
"#F06543",  //food
"#320E3B",  //snake
"#313638"   //text
],
["black", //background
"#fc0fc0aa",  //playground
"#a3f",  //food
"#a3f",  //snake
"black"   //text
],
["#B0413E", //background
"#473335aa",  //playground
"#548687",  //food
"#FFFFC7",  //snake
"#FCAA67"   //text
],
["#DAE0F2", //background
"#AA00AAcc",  //playground
"#F9CFF2",  //food
"#111344",  //snake
"#F9CFF2"   //text
],
];

var score = 0;
var c = Math.floor(Math.random()*colorArray.length);
var nc = 0;
var game = 1;
var blink = 0;
var snek = new snake();
var fond = new food();
fond.spawn();
