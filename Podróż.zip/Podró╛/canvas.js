var canvas = document.querySelector('canvas');
var lines = false;

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

var canWidth = innerWidth;
var canHeight = innerHeight;

var c = canvas.getContext('2d');

window.addEventListener('resize', function(event){
	canvas.width = window.innerWidth;
	canvas.height = window.innerHeight;
	canHeight = canvas.height;
	canWidth = canvas.width;
});

var mouse = {
	x: undefined,
	y: undefined
}

window.addEventListener('mousemove', function(event){
	mouse.x = event.x;
	mouse.y = event.y;
});

						
function Balloon() {
    this.color = 0;
    this.x = canWidth/2;
    this.y = canHeight/2;
    this.radius = 1;
    this.dx = (Math.random()-0.5)*8;
    this.dy = (Math.random()-0.5)*8;

	this.draw = function() {
		c.beginPath();
		c.arc(this.x, this.y, this.radius, 0, Math.PI*2, false);
		c.lineWidth = 2;
		c.fillStyle = 'rgb('+this.color+','+this.color+','+this.color+')';
		c.fill();
	}

	this.update = function() {
    this.y += this.dy;
    this.x += this.dx;
    this.radius +=0.05;
	this.draw();
	this.color+=0.5;
	if(this.y - this.radius > canHeight || this.y + this.radius < 0 || this.x - this.radius > canWidth || this.x + this.radius < 0){
	    this.radius = 1;
	    this.x = innerWidth/2;
	    this.y = innerHeight/2;
	    this.dx = (Math.random()-0.5)*8;
        this.dy = (Math.random()-0.5)*8;
		this.color = 0;
	}
	}
}

var BalloonArray = [];
for(var i = 0; i < 60; i++)
BalloonArray.push(new Balloon());
function animate(){
    requestAnimationFrame(animate);
    c.beginPath();
	c.fillStyle = '#22222299';
	c.fillRect(0, 0, innerWidth, innerHeight);
	c.closePath();
	for(var i=0; i<BalloonArray.length; i++)
	{
	BalloonArray[i].update();
	}
}


